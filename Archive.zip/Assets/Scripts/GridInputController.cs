using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class GridInputController : MonoBehaviour {
  Tilemap _tilemap;
  Vector3Int _tilemapOffset;

  class Decomposer {
    public readonly float maxDuration = 5f;
    public readonly float strength = 20f;
    public float durationRemaining;
    public ParticleSystem DecomposerEffect;

    public Decomposer(ParticleSystem decomposerEffect) {
      durationRemaining = maxDuration;
      DecomposerEffect = decomposerEffect;
    }

    public void Update(float deltaTime) {
      durationRemaining -= deltaTime;
    }
  }

  class Decomposable {
    public readonly SpriteRenderer spriteRenderer;
    public readonly Vector3Int TilemapPosition;
    public readonly float maxHealth = 100;
    public float healthRemaining;

    public Decomposable(Vector3Int tilemapPosition, SpriteRenderer spriteRenderer) {
      healthRemaining = maxHealth;
      TilemapPosition = tilemapPosition;
      this.spriteRenderer = spriteRenderer;
    }
  }

  Decomposer[,] _decomposers = new Decomposer[18, 10];
  Dictionary<Vector3Int, Decomposer> _decomposerMap = new();
  Decomposable[,] _decomposables = new Decomposable[18, 10];
  Dictionary<Vector3Int, Decomposable> _decomposableMap = new();

  [SerializeField] ParticleSystem WormEffect;
  [SerializeField] GameObject RatSprite;

  // Start is called before the first frame update
  void Start() {
    _tilemap = this.GetComponent<Tilemap>();
    _tilemapOffset = Vector3Int.FloorToInt(_tilemap.localBounds.max);
  }

  // Update is called once per frame
  void Update() {
    Vector3Int tilemapPos = _tilemap.WorldToCell(Camera.main.ScreenToWorldPoint(Input.mousePosition)) + _tilemapOffset;
    //Debug.Log("tilepos = " + tilemapPos);

    if (Input.GetMouseButton(0)) {
      SpawnBugsAtClick();
    }
    if (Input.GetMouseButton(1)) {
      SpawnRatAtClick();
    }

    UpdateDecomposables();
    UpdateDecomposers();
  }

  void SpawnBugsAtClick() {
    Vector3Int clickedCell = _tilemap.WorldToCell(Camera.main.ScreenToWorldPoint(Input.mousePosition));

    Vector3Int adjustedClickedCell = clickedCell + _tilemapOffset;
    if (_decomposers[adjustedClickedCell.x, adjustedClickedCell.y] == null) {
      Decomposer decomposer = new Decomposer(WormEffect);
      _decomposers[adjustedClickedCell.x, adjustedClickedCell.y] = decomposer;
      _decomposerMap.Add(adjustedClickedCell, decomposer);

      Vector3 centerOfClickedCell = _tilemap.GetCellCenterLocal(clickedCell);
      Instantiate(WormEffect, centerOfClickedCell, Quaternion.identity, transform);
    }
  }

  void SpawnRatAtClick() {
    Vector3Int clickedCell = _tilemap.WorldToCell(Camera.main.ScreenToWorldPoint(Input.mousePosition));

    Vector3Int adjustedClickedCell = clickedCell + _tilemapOffset;
    if (_decomposables[adjustedClickedCell.x, adjustedClickedCell.y] == null) {

      Vector3 centerOfClickedCell = _tilemap.GetCellCenterLocal(clickedCell);
      GameObject ratObject = Instantiate(RatSprite, centerOfClickedCell, RatSprite.transform.rotation, transform);

      Decomposable decomposable = new Decomposable(adjustedClickedCell, ratObject.GetComponent<SpriteRenderer>());
      _decomposables[adjustedClickedCell.x, adjustedClickedCell.y] = decomposable;
      _decomposableMap.Add(adjustedClickedCell, decomposable);
    }
  }

  void UpdateDecomposables() {
    List<Vector3Int> deleteKeys = new();
    foreach (Vector3Int tilemapPos in _decomposableMap.Keys) {
      if (_decomposerMap.ContainsKey(tilemapPos)) {
        UpdateDecomposable(_decomposableMap[tilemapPos], _decomposerMap[tilemapPos]);
      }
      if (_decomposableMap[tilemapPos].healthRemaining <= 0) {
        Debug.Log("decomposable finished");
        deleteKeys.Add(tilemapPos);
      }
    }

    foreach (Vector3Int tilemapPos in deleteKeys) {
      Destroy(_decomposableMap[tilemapPos].spriteRenderer);
      _decomposableMap.Remove(tilemapPos);
      _decomposables[tilemapPos.x, tilemapPos.y] = null;
    }
  }

  void UpdateDecomposable(Decomposable decomposable, Decomposer decomposer) {
    decomposable.healthRemaining -= decomposer.strength * Time.deltaTime;

    Color decomposableColor = decomposable.spriteRenderer.color;
    decomposableColor.a = decomposable.healthRemaining / decomposable.maxHealth;
    decomposable.spriteRenderer.color = decomposableColor;
  }

  void UpdateDecomposers() {
    List<Vector3Int> deleteKeys = new();
    foreach (Vector3Int tilemapPos in _decomposerMap.Keys) {
      Decomposer decomposer = _decomposerMap[tilemapPos];
      decomposer.Update(Time.deltaTime);

      if (decomposer.durationRemaining <= 0) {
        Debug.Log("decomposer finished");
        deleteKeys.Add(tilemapPos);
      }
    }

    foreach (Vector3Int tilemapPos in deleteKeys) {
      //DestroyImmediate(_decomposerMap[tilemapPos].DecomposerEffect);
      _decomposerMap[tilemapPos].DecomposerEffect.loop = false;
      _decomposerMap.Remove(tilemapPos);
      _decomposers[tilemapPos.x, tilemapPos.y] = null;
    }
  }
}
